// MineTrack Pro - Fleet Management, Diesel Expense & Slip OCR Engine
// Configured with exact real-world fleet data from Kutch Mining Region (Mandvi/Vandh)

const DB_KEY = 'FLEET_BILLING_SYSTEM_DATA_V3';

// Sample real slip from user upload
const USER_SLIP_IMAGE = 'sample_weighment_slip.jpg';

const DEFAULT_FLEET_DATA = {
  config: {
    transporterName: 'Om Shiv Shakti Transport & Fleet Services',
    ownerName: 'Kalpesh Vaghela',
    headOffice: 'Village Vandh, Taluka Mandvi, Kutch, Gujarat - 370485',
    phone: '+91 83477 26372 / +91 98250 12345',
    gstin: '24ABCDE1234F1Z6',
    defaultTruckNo: 'GJ39TB1972',
    defaultWeighbridgeRate: 100, // Standard ₹100 per slip
    dieselRate: 90.88,
    currencySymbol: '₹'
  },

  // Fleet Trucks
  trucks: [
    { truckNo: 'GJ39TB1972', model: 'BharatBenz 3528C Mining Tipper (12-Wheeler)', tareWeight: 15.23, capacityMT: 42, driverName: 'Ramesh Yadav', driverPhone: '9845011223', status: 'Active' },
    { truckNo: 'GJ39T4521', model: 'Tata Signa 3523.TK (12-Wheeler)', tareWeight: 14.80, capacityMT: 40, driverName: 'Sunil Naik', driverPhone: '9845011224', status: 'Active' }
  ],

  // Frequent Companies / Clients (from user's real register)
  companies: [
    'GIMPEX', 'SWELL WELL', 'DABASIYA', 'SHIVANI MINECHEM', 'MA WAGESWARI',
    'KUTCH BENTOCLAY', 'SHIV MINERALS', 'LAVIOSA', 'AKSHAR', 'JAYKAY',
    'RAMDEV MINES', 'MANVI', 'V & H (MAVJIBHAI S)', 'SHIVAM', 'AISHWARYA',
    'MAVJI KAKA', 'RADHE KRISHNA VIJAY', 'VAN BENT', 'CMS', 'DARSHANA'
  ],

  // Common Loading & Unloading addresses (from user's real register)
  loadingAddresses: [
    'VANDH', 'BANDH 288', 'BILAVNATH', 'VIPUL PLOT', 'SUNIL PLOT',
    'DIGUBHA KHAN', 'RAJUBHA 288', 'BHAMATAR', 'SERDI PLOT', 'HAMLA',
    'NEW SHREE', 'K.S PLOT', 'AKODIO 294', 'RATADIYA KHAN', 'PASI'
  ],

  unloadingAddresses: [
    'DESALPAR RENK', 'SANOSARA RENK', 'SWELL WELL MILL', 'DABASIYA KOJACHORA',
    'DURGAPUR', 'SAMTRA', 'BHAMATAR', 'SHIVANI MILL', 'LAVIOSA MILL',
    'KAPAYA MILL', 'KUTCH BENTO MILL', 'MINPRO MILL', 'MANVI MILL'
  ],

  // Known Weighbridges
  weighbridges: [
    { name: 'SHREE WEIGHBRIDGE (Vandh)', shortName: 'SHREE', charge: 100 },
    { name: '72 KRUPA WEIGHBRIDGE', shortName: '72 KRUPA', charge: 100 },
    { name: 'ASHAPURA WEIGHBRIDGE', shortName: 'ASHAPURA', charge: 100 },
    { name: 'CHAMUNDA WEIGHBRIDGE', shortName: 'CHAMUNDA', charge: 100 },
    { name: 'RADHE WEIGHBRIDGE', shortName: 'RADHE', charge: 100 },
    { name: 'BAPA DAYALU WEIGHBRIDGE', shortName: 'BAPA DAYALU', charge: 100 }
  ],

  // Real Fleet Trips imported from user's actual ledger
  trips: [
    // --- LATEST NOVEMBER 2026 TRIPS (MATCHING USER'S UPLOADED WEIGHMENT SLIPS!) ---
    {
      id: 'TRP-26702',
      serialNo: '26702', // Exact ticket from uploaded slip!
      date: '2026-11-05',
      time: '18:40',
      truckNo: 'GJ39TB1972', // Exact vehicle from slip!
      companyName: 'GIMPEX', // Customer from slip: GIMPEX IMREYS DESALPA
      loadingAddress: 'VANDH',
      unloadingAddress: 'DESALPAR RENK',
      material: 'BENTONITE', // Item from slip
      grossWeightKg: 57080,
      tareWeightKg: 15230,
      netWeightKg: 41850,
      truckTon: 41.85, // 41850 Kg = 41.85 MT
      tonRate: 235,
      totalAmount: 9834.75, // 41.85 * 235
      loaderName: 'SHREE',
      loaderRs: 0,
      weighbridgeName: 'SHREE', // From slip
      weighbridgeRs: 100, // Charges: 100 from slip
      dieselLtrs: 40,
      dieselRate: 90.88,
      dieselTotal: 3635.20,
      driverRs: 400,
      maintenanceRs: 0,
      slipPhoto: USER_SLIP_IMAGE, // Linked to the user's real slip photo!
      ocrVerified: true,
      remarks: 'Auto-extracted from Shree Weighbridge slip #26702'
    },
    {
      id: 'TRP-26730',
      serialNo: '26730', // Exact ticket from bottom slip!
      date: '2026-11-05',
      time: '22:34',
      truckNo: 'GJ39TB1972',
      companyName: 'GIMPEX',
      loadingAddress: 'VANDH',
      unloadingAddress: 'DESALPAR RENK',
      material: 'BENTONITE',
      grossWeightKg: 56030,
      tareWeightKg: 15230,
      netWeightKg: 40800,
      truckTon: 40.80, // 40800 Kg = 40.80 MT
      tonRate: 235,
      totalAmount: 9588.00, // 40.80 * 235
      loaderName: 'SHREE',
      loaderRs: 0,
      weighbridgeName: 'SHREE',
      weighbridgeRs: 100,
      dieselLtrs: 0,
      dieselRate: 90.88,
      dieselTotal: 0,
      driverRs: 400,
      maintenanceRs: 0,
      slipPhoto: USER_SLIP_IMAGE,
      ocrVerified: true,
      remarks: 'Auto-extracted from Shree Weighbridge slip #26730'
    },

    // --- OCTOBER 2026 SAMPLES ---
    { id: 'OCT-01', serialNo: '2729', date: '2026-10-01', truckNo: 'GJ39TB1972', companyName: 'SHAKTI (SUNIL)', loadingAddress: 'VANDH', unloadingAddress: 'DESALPAR RENK', truckTon: 24.61, tonRate: 250, totalAmount: 6152.50, loaderName: '', loaderRs: 0, weighbridgeName: 'SHREE', weighbridgeRs: 100, dieselLtrs: 0, dieselRate: 0, dieselTotal: 0, driverRs: 0, maintenanceRs: 0 },
    { id: 'OCT-02', serialNo: '25906', date: '2026-10-03', truckNo: 'GJ39TB1972', companyName: 'MA ASHAPURA', loadingAddress: '37 PLOT', unloadingAddress: 'ASHAPURA MILL VANDH', truckTon: 26.69, tonRate: 50, totalAmount: 1334.50, loaderName: '', loaderRs: 0, weighbridgeName: 'ASHAPURA', weighbridgeRs: 100, dieselLtrs: 0, dieselRate: 0, dieselTotal: 0, driverRs: 0, maintenanceRs: 0 },
    { id: 'OCT-03', serialNo: '25909', date: '2026-10-03', truckNo: 'GJ39TB1972', companyName: 'KUTCH BENTOCLAY', loadingAddress: 'K.S', unloadingAddress: 'KUTCH BENTO MILL', truckTon: 25.93, tonRate: 170, totalAmount: 4408.10, loaderName: '', loaderRs: 0, weighbridgeName: 'SHREE', weighbridgeRs: 100, dieselLtrs: 0, dieselRate: 0, dieselTotal: 0, driverRs: 0, maintenanceRs: 0 },
    { id: 'OCT-04', serialNo: '25910', date: '2026-10-03', truckNo: 'GJ39TB1972', companyName: 'KUTCH BENTOCLAY', loadingAddress: 'K.S', unloadingAddress: 'KUTCH BENTO MILL', truckTon: 25.49, tonRate: 170, totalAmount: 4333.30, loaderName: '', loaderRs: 0, weighbridgeName: 'SHREE', weighbridgeRs: 100, dieselLtrs: 0, dieselRate: 0, dieselTotal: 0, driverRs: 0, maintenanceRs: 0 },

    // --- JUNE 2026 SAMPLES ---
    { id: 'JUN-01', serialNo: '23780', date: '2026-06-01', truckNo: 'GJ39TB1972', companyName: 'SWELL WELL', loadingAddress: 'BILAVNATH', unloadingAddress: 'SWELL WELL MILL', truckTon: 25.84, tonRate: 154, totalAmount: 3979.36, loaderName: '', loaderRs: 0, weighbridgeName: 'SHREE', weighbridgeRs: 100, dieselLtrs: 0, dieselRate: 0, dieselTotal: 0, driverRs: 0, maintenanceRs: 0 },
    { id: 'JUN-02', serialNo: '23794', date: '2026-06-01', truckNo: 'GJ39TB1972', companyName: 'SWELL WELL', loadingAddress: 'BILAVNATH', unloadingAddress: 'SWELL WELL MILL', truckTon: 24.04, tonRate: 154, totalAmount: 3702.16, loaderName: '', loaderRs: 0, weighbridgeName: 'SHREE', weighbridgeRs: 100, dieselLtrs: 0, dieselRate: 0, dieselTotal: 0, driverRs: 0, maintenanceRs: 0 },
    { id: 'JUN-03', serialNo: '24091', date: '2026-06-04', truckNo: 'GJ39TB1972', companyName: 'LAVIOSA', loadingAddress: '294', unloadingAddress: 'LAVIOSA MILL', truckTon: 22.95, tonRate: 154, totalAmount: 3534.30, loaderName: '', loaderRs: 0, weighbridgeName: 'SHREE', weighbridgeRs: 100, dieselLtrs: 0, dieselRate: 0, dieselTotal: 0, driverRs: 0, maintenanceRs: 0 },
    { id: 'JUN-04', serialNo: '24339', date: '2026-06-06', truckNo: 'GJ39TB1972', companyName: 'MAXIM', loadingAddress: 'VANDH', unloadingAddress: 'DESALPAR RENK', truckTon: 24.38, tonRate: 235, totalAmount: 5729.30, loaderName: '', loaderRs: 0, weighbridgeName: 'SHREE', weighbridgeRs: 100, dieselLtrs: 0, dieselRate: 0, dieselTotal: 0, driverRs: 0, maintenanceRs: 0 },

    // --- MAY 2026 SAMPLES ---
    { id: 'MAY-01', serialNo: '21454', date: '2026-05-02', truckNo: 'GJ39TB1972', companyName: 'SHIVANI', loadingAddress: 'NEW SHREE', unloadingAddress: 'SHIVANI MILL', truckTon: 24.03, tonRate: 160, totalAmount: 3844.80, loaderName: '', loaderRs: 0, weighbridgeName: 'SHREE', weighbridgeRs: 100, dieselLtrs: 0, dieselRate: 0, dieselTotal: 0, driverRs: 0, maintenanceRs: 0 },
    { id: 'MAY-02', serialNo: '19236', date: '2026-05-02', truckNo: 'GJ39TB1972', companyName: 'PITRU KRUPA MAVJI KAKA', loadingAddress: 'SERDI PLOT', unloadingAddress: 'PITRU KRUPA MILL', truckTon: 23.91, tonRate: 150, totalAmount: 3586.50, loaderName: '', loaderRs: 0, weighbridgeName: 'CHAMUNDA', weighbridgeRs: 100, dieselLtrs: 0, dieselRate: 0, dieselTotal: 0, driverRs: 0, maintenanceRs: 0 },
    { id: 'MAY-03', serialNo: '9767', date: '2026-05-03', truckNo: 'GJ39TB1972', companyName: 'AKSHAR', loadingAddress: 'VANDH', unloadingAddress: 'SANOSARA RENK', truckTon: 24.76, tonRate: 255, totalAmount: 6313.80, loaderName: '', loaderRs: 0, weighbridgeName: 'SHREE', weighbridgeRs: 100, dieselLtrs: 0, dieselRate: 0, dieselTotal: 0, driverRs: 0, maintenanceRs: 0 },

    // --- FEBRUARY 2026 SAMPLES (WITH REAL DIESEL & LOADER) ---
    { id: 'FEB-01', serialNo: '35739', date: '2026-02-02', truckNo: 'GJ39TB1972', companyName: 'MA WAGESWARI', loadingAddress: 'DIGUBHA KHAN', unloadingAddress: 'BHAMATAR', truckTon: 32.30, tonRate: 50, totalAmount: 1615.00, loaderName: '', loaderRs: 0, weighbridgeName: '72 KRUPA', weighbridgeRs: 100, dieselLtrs: 280.48, dieselRate: 98.88, dieselTotal: 27733.86, driverRs: 0, maintenanceRs: 0 },
    { id: 'FEB-02', serialNo: '35745', date: '2026-02-02', truckNo: 'GJ39TB1972', companyName: 'MA WAGESWARI', loadingAddress: 'DIGUBHA KHAN', unloadingAddress: 'BHAMATAR', truckTon: 29.80, tonRate: 50, totalAmount: 1490.00, loaderName: '', loaderRs: 0, weighbridgeName: '72 KRUPA', weighbridgeRs: 100, dieselLtrs: 0, dieselRate: 0, dieselTotal: 0, driverRs: 0, maintenanceRs: 0 },
    { id: 'FEB-11', serialNo: '16531', date: '2026-02-02', truckNo: 'GJ39TB1972', companyName: 'DABASIYA', loadingAddress: 'NEW SHREE', unloadingAddress: 'DABASIYA KOJACHORA', truckTon: 24.72, tonRate: 120, totalAmount: 2966.40, loaderName: 'SHREE', loaderRs: 494.40, weighbridgeName: 'SHREE', weighbridgeRs: 100, dieselLtrs: 0, dieselRate: 0, dieselTotal: 0, driverRs: 0, maintenanceRs: 0 },

    // --- JANUARY 2026 SAMPLES (INCLUDING BREAKDOWN EVENT) ---
    { id: 'JAN-01', serialNo: '47884', date: '2026-01-01', truckNo: 'GJ39TB1972', companyName: 'BMMI HOSPET', loadingAddress: 'VANDH', unloadingAddress: 'SANOSARA RENK', truckTon: 23.87, tonRate: 255, totalAmount: 6086.85, loaderName: '', loaderRs: 0, weighbridgeName: 'SHREE', weighbridgeRs: 100, dieselLtrs: 320.57, dieselRate: 90.88, dieselTotal: 29133.40, driverRs: 0, maintenanceRs: 0 },
    { id: 'JAN-02', serialNo: '47928', date: '2026-01-01', truckNo: 'GJ39TB1972', companyName: 'BMMI HOSPET', loadingAddress: 'VANDH', unloadingAddress: 'SANOSARA RENK', truckTon: 23.80, tonRate: 255, totalAmount: 6069.00, loaderName: '', loaderRs: 0, weighbridgeName: 'SHREE', weighbridgeRs: 100, dieselLtrs: 0, dieselRate: 0, dieselTotal: 0, driverRs: 0, maintenanceRs: 0 },
    { id: 'JAN-26', serialNo: 'MAINT-01', date: '2026-01-10', truckNo: 'GJ39TB1972', companyName: 'MAINTENANCE', loadingAddress: 'GADI NA ENGIN MA', unloadingAddress: 'PANI AAVI JAVATHI BANDH', truckTon: 0, tonRate: 0, totalAmount: 0, loaderName: '', loaderRs: 0, weighbridgeName: '', weighbridgeRs: 0, dieselLtrs: 0, dieselRate: 0, dieselTotal: 0, driverRs: 0, maintenanceRs: 4500, remarks: 'Engine water leakage repair & cooling hose replacement' }
  ]
};

// Database API
const FleetDB = {
  get: function() {
    try {
      const stored = localStorage.getItem(DB_KEY);
      if (!stored) {
        this.save(DEFAULT_FLEET_DATA);
        return JSON.parse(JSON.stringify(DEFAULT_FLEET_DATA));
      }
      return JSON.parse(stored);
    } catch (e) {
      console.warn('Error reading from storage:', e);
      return JSON.parse(JSON.stringify(DEFAULT_FLEET_DATA));
    }
  },

  save: function(data) {
    try {
      localStorage.setItem(DB_KEY, JSON.stringify(data));
      return true;
    } catch (e) {
      console.error('Storage save failed:', e);
      return false;
    }
  },

  resetToDefault: function() {
    this.save(DEFAULT_FLEET_DATA);
    return JSON.parse(JSON.stringify(DEFAULT_FLEET_DATA));
  },

  addTrip: function(trip) {
    const data = this.get();
    data.trips.unshift(trip);
    this.save(data);
    return trip;
  },

  updateTrip: function(id, updatedFields) {
    const data = this.get();
    const idx = data.trips.findIndex(t => t.id === id);
    if (idx !== -1) {
      data.trips[idx] = { ...data.trips[idx], ...updatedFields };
      this.save(data);
      return data.trips[idx];
    }
    return null;
  },

  deleteTrip: function(id) {
    const data = this.get();
    data.trips = data.trips.filter(t => t.id !== id);
    this.save(data);
  },

  exportJSON: function() {
    return JSON.stringify(this.get(), null, 2);
  },

  importJSON: function(jsonStr) {
    try {
      const parsed = JSON.parse(jsonStr);
      if (parsed.trips && parsed.config) {
        this.save(parsed);
        return { success: true };
      }
      return { success: false, error: 'Invalid file format' };
    } catch (e) {
      return { success: false, error: e.message };
    }
  }
};
